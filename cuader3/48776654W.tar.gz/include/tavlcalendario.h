#ifndef _TAVLCALENDARIO_H_
#define _TAVLCALENDARIO_H_

#include <iostream>
#include "tvectorcalendario.h"

class TNodoAVL;

class TAVLCalendario {
    friend ostream & operator<<(ostream &, const TAVLCalendario &);
    private:
        TNodoAVL *raiz; // Puntero a la raíz del árbol
        void InordenAux(TVectorCalendario &, int &) const; // Método auxiliar para recorrido en inorden
        void PreordenAux(TVectorCalendario &, int &) const; // Método auxiliar para recorrido en preorden
        void PostordenAux(TVectorCalendario &, int &) const; // Método auxiliar para recorrido en postorden
        void Copiar(const TAVLCalendario &); // Método para copiar un árbol AVL
        TCalendario mayorIz(); // Método para obtener el mayor elemento de la rama izquierda
        TNodoAVL* BuscarPunteroNodo(TCalendario, TNodoAVL*); // Método para buscar un nodo por su valor
        void RotacionSimpleDerecha(TNodoAVL *&); // Método para realizar una rotación simple a la derecha
        void RotacionSimpleIzquierda(TNodoAVL *&); // Método para realizar una rotación simple a la izquierda
        void RotacionDobleDerecha(TNodoAVL *&); // Método para realizar una rotación doble a la derecha
        void RotacionDobleIzquierda(TNodoAVL *&); // Método para realizar una rotación doble a la izquierda
        TNodoAVL* BuscarPadre(TCalendario &); // Método para buscar el nodo padre de un nodo dado

    public:
        TAVLCalendario(); // Constructor por defecto
        TAVLCalendario(const TAVLCalendario &); // Constructor de copia
        ~TAVLCalendario(); // Destructor
        TAVLCalendario & operator=(const TAVLCalendario &); // Sobrecarga del operador de asignación
        bool operator==(const TAVLCalendario &) const; // Sobrecarga del operador de igualdad
        bool operator!=(const TAVLCalendario &) const; // Sobrecarga del operador de desigualdad
        bool EsVacio() const; // Comprueba si el árbol está vacío
        bool Insertar(TCalendario &); // Inserta un elemento en el árbol
        bool Borrar(TCalendario &); // Borra un elemento del árbol
        bool Buscar(const TCalendario &) const; // Busca un elemento en el árbol
        TCalendario Raiz() const; // Devuelve la raíz del árbol
        int Altura() const; // Devuelve la altura del árbol
        int Nodos() const; // Devuelve el número de nodos del árbol
        int NodosHoja() const; // Devuelve el número de nodos hoja del árbol
        TVectorCalendario Inorden() const; // Devuelve el recorrido en inorden del árbol
        TVectorCalendario Preorden() const; // Devuelve el recorrido en preorden del árbol
        TVectorCalendario Postorden() const; // Devuelve el recorrido en postorden del árbol
        TVectorCalendario Niveles() const; // Devuelve el recorrido por niveles del árbol
        TAVLCalendario operator+(const TAVLCalendario &) const; // Sobrecarga del operador de unión
        TAVLCalendario operator-(const TAVLCalendario &) const; // Sobrecarga del operador de diferencia
};

class TNodoAVL {
    friend class TAVLCalendario;
    private:
        TCalendario item; // Elemento almacenado en el nodo
        TAVLCalendario iz, de; // Subárboles izquierdo y derecho
        int fe; // Factor de equilibrio
    public:
        TNodoAVL(); // Constructor por defecto
        TNodoAVL(const TNodoAVL &); // Constructor de copia
        ~TNodoAVL(); // Destructor
        TNodoAVL & operator=(const TNodoAVL &); // Sobrecarga del operador de asignación
        bool EsHoja() const; // Comprueba si el nodo es hoja
};

#endif