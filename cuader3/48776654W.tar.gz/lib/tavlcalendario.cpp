#include "tavlcalendario.h"
#include <iostream>
#include <queue>

// Constructor por defecto de TNodoAVL
TNodoAVL::TNodoAVL() : item(), iz(), de(), fe() {}

// Constructor de copia de TNodoAVL
TNodoAVL::TNodoAVL(const TNodoAVL &tnodo) : item(tnodo.item), iz(tnodo.iz), de(tnodo.de), fe(tnodo.fe) {}

// Destructor de TNodoAVL
TNodoAVL::~TNodoAVL() {}

// Sobrecarga del operador de asignación de TNodoAVL
TNodoAVL & TNodoAVL::operator=(const TNodoAVL &tnodo) {
    if(this != &tnodo){
        this->~TNodoAVL();
        this->iz = tnodo.iz;
        this->de = tnodo.de;
        this->item = tnodo.item;
        this->fe = tnodo.fe;
    }
    return *this;
}

// Comprueba si el nodo es hoja
bool TNodoAVL::EsHoja() const {
    return iz.EsVacio() && de.EsVacio();
}

// TAVLCalendario

// Comprueba si el árbol está vacío
bool TAVLCalendario::EsVacio() const {
    return (raiz == NULL);
}

// Devuelve la raíz del árbol
TCalendario TAVLCalendario::Raiz() const {
    TCalendario aux;

    if(raiz != NULL){
        aux = raiz->item;
    }

    return aux;
}

// Método auxiliar para recorrido en inorden
void TAVLCalendario::InordenAux(TVectorCalendario &tvec, int &pos) const {
    if(raiz != NULL){
        (raiz->iz).InordenAux(tvec, pos);
        tvec[pos] = Raiz();
        pos++;
        (raiz->de).InordenAux(tvec, pos);
    }
}

// Método auxiliar para recorrido en preorden
void TAVLCalendario::PreordenAux(TVectorCalendario &tvec, int &pos) const {
    if(raiz != NULL){
        tvec[pos] = Raiz();
        pos++;
        (raiz->iz).PreordenAux(tvec, pos);
        (raiz->de).PreordenAux(tvec, pos);
    }
}

// Método auxiliar para recorrido en postorden
void TAVLCalendario::PostordenAux(TVectorCalendario &tvec, int &pos) const {
    if(raiz != NULL){
        (raiz->iz).PostordenAux(tvec, pos);
        (raiz->de).PostordenAux(tvec, pos);
        tvec[pos] = Raiz();
        pos++;
    }
}

// Devuelve la altura del árbol
int TAVLCalendario::Altura() const {
    int altura_iz = 0;
    int altura_de = 0;
    
    if(EsVacio()){
        return 0;
    } else {
        altura_iz = (raiz->iz).Altura();
        altura_de = (raiz->de).Altura();
        return (1 + max(altura_iz, altura_de));
    }
}

// Devuelve el número de nodos del árbol
int TAVLCalendario::Nodos() const {
    if(EsVacio()){
        return 0;
    }
    else{
        return (1 + (raiz->iz).Nodos() + (raiz->de).Nodos());
    }
}

// Devuelve el número de nodos hoja del árbol
int TAVLCalendario::NodosHoja() const {
    if(EsVacio()){
        return 0;
    } else {
        if((raiz->iz).EsVacio() && (raiz->de).EsVacio()){
            return 1;
        } else {
            return (raiz->iz).NodosHoja() + (raiz->de).NodosHoja();
        }
    }
}

// Busca un elemento en el árbol
bool TAVLCalendario::Buscar(const TCalendario &cal) const
{
    if(EsVacio()){
        return false;
    }
    if(raiz->item == cal){
        return true;
    } else {
        return (raiz->iz).Buscar(cal) || (raiz->de).Buscar(cal);
    }
}

// Constructor por defecto de TAVLCalendario
TAVLCalendario::TAVLCalendario() {
    raiz = NULL;
}

// Método para copiar un árbol AVL
void TAVLCalendario::Copiar(const TAVLCalendario &tavl) {
    if(tavl.raiz != NULL){
        TNodoAVL *aux = new TNodoAVL();
        aux->item = tavl.raiz->item;
        raiz = aux;
        (raiz->iz).Copiar(tavl.raiz->iz);
        (raiz->de).Copiar(tavl.raiz->de);
    }
    else raiz = NULL;
}

// Constructor de copia de TAVLCalendario
TAVLCalendario::TAVLCalendario(const TAVLCalendario &tavl) {
    if(this != &tavl) Copiar(tavl);
}

// Destructor de TAVLCalendario
TAVLCalendario::~TAVLCalendario() {
    if(raiz != NULL){
        delete raiz;
        raiz = NULL;
    }
}

// Sobrecarga del operador de asignación de TAVLCalendario
TAVLCalendario & TAVLCalendario::operator=(const TAVLCalendario &tavl) {
    if(this != &tavl){
        this->~TAVLCalendario();
        Copiar(tavl);
    }
    return *this;
}

// Método para buscar un nodo por su valor
TNodoAVL* TAVLCalendario::BuscarPunteroNodo(TCalendario cal, TNodoAVL *tnodoraiz){
    if(EsVacio()) return NULL;

    if(cal > raiz->item) {
        tnodoraiz = raiz;
        return (raiz->de).BuscarPunteroNodo(cal, tnodoraiz);
    }
    if(cal < raiz->item) {
        tnodoraiz = raiz;
        return (raiz->iz).BuscarPunteroNodo(cal, tnodoraiz);  
    }   
    return raiz;
}

// Inserta un elemento en el árbol
bool TAVLCalendario::Insertar(TCalendario &c) {
    bool retorno=true;
	TNodoAVL *nodo, *A,*B,*C,*D,*E,*F;
	if(EsVacio())
	{
		nodo=new TNodoAVL();
		if(!nodo) retorno=false;
		nodo->item=c;
		nodo->fe=0;
		raiz=nodo;
	}
	else
	{
		if(c==raiz->item) retorno=false;
		else
		{
			if(c<raiz->item)
			{
				retorno=raiz->iz.Insertar(c);
			}
			else
			{
				if(c>raiz->item) retorno=raiz->de.Insertar(c);
			}
		}
	}
	raiz->fe=raiz->de.Altura()-raiz->iz.Altura();
	if(raiz->fe==-2)
	{
		if(raiz->iz.raiz->fe==-1)
		{
			D=raiz;
			B=D->iz.raiz;
			C=B->de.raiz;
			raiz=B;
			raiz->de.raiz=D;
			D->iz.raiz=C;
			D->fe=D->de.Altura()-D->iz.Altura();
		}
		else
			if(raiz->iz.raiz->fe==1)
			{
				F=raiz;
				B=raiz->iz.raiz;
				D=B->de.raiz;
				C=D->iz.raiz;
				E=D->de.raiz;
				raiz=D;
				raiz->iz.raiz=B;
				raiz->de.raiz=F;
				raiz->de.raiz->iz.raiz=E;
				raiz->iz.raiz->de.raiz=C;
				B->fe=B->de.Altura()-B->iz.Altura();
				D->fe=D->de.Altura()-D->iz.Altura();
			}
	}
	else
		if(raiz->fe==2)
		{
			if(raiz->de.raiz->fe==1)
			{
				D=raiz;
				B=D->de.raiz;
				C=B->iz.raiz;
				raiz=B;
				raiz->iz.raiz=D;
				D->de.raiz=C;
				D->fe=D->de.Altura()-D->iz.Altura();
			}
			else
				if(raiz->de.raiz->fe==-1)
				{
					F=raiz;
					B=raiz->de.raiz;
					D=B->iz.raiz;
					C=D->de.raiz;
					E=D->iz.raiz;
					raiz=D;
					raiz->de.raiz=B;
					raiz->iz.raiz=F;
					raiz->de.raiz->iz.raiz=C;
					raiz->iz.raiz->de.raiz=E;
					B->fe=B->de.Altura()-B->iz.Altura();
					D->fe=D->de.Altura()-D->iz.Altura();
				}
		}
	raiz->fe=raiz->de.Altura()-raiz->iz.Altura();
	return retorno;
}

// Sobrecarga del operador de igualdad de TAVLCalendario
bool TAVLCalendario::operator==(const TAVLCalendario &tavl) const {
    TVectorCalendario vIZ = Inorden();
    TVectorCalendario vDE = tavl.Inorden();

    return vIZ == vDE;
}

// Sobrecarga del operador de desigualdad de TAVLCalendario
bool TAVLCalendario::operator!=(const TAVLCalendario &tavl) const {
    return !(*this == tavl);
}

// Método para obtener el mayor elemento de la rama izquierda
TCalendario TAVLCalendario::mayorIz() {
    TCalendario cal;

    if(EsVacio()) {
        return cal;
    }
    else{
        if((raiz->de).EsVacio()){
            cal = raiz->item;
        }
        else {
            cal = raiz->de.mayorIz();
        }
    }
    return cal;
}

bool TAVLCalendario::Borrar(TCalendario &cal) {
    bool retorno = true;
    TNodoAVL *aux = raiz, *padre = NULL, *nodo_sustituto, *padre_sustituto;
    TCalendario menor;

    // Búsqueda del nodo a borrar
    while (aux != NULL && aux->item != cal) {
        padre = aux;
        if (cal < aux->item) {
            aux = aux->iz.raiz;
        } else {
            aux = aux->de.raiz;
        }
    }

    if (aux == NULL) {
        // El elemento no se encuentra en el árbol
        retorno = false;
    } else {
        // El elemento se encuentra en el árbol
        if (aux->iz.EsVacio() && aux->de.EsVacio()) {
            // Caso 1: Nodo a borrar es una hoja
            if (padre == NULL) {
                // El nodo a borrar es la raíz
                raiz = NULL;
            } else if (padre->iz.raiz == aux) {
                padre->iz.raiz = NULL;
            } else {
                padre->de.raiz = NULL;
            }
            delete aux;
        } else if (aux->iz.EsVacio() || aux->de.EsVacio()) {
            // Caso 2: Nodo a borrar tiene un solo hijo
            TNodoAVL *hijo;
            if (aux->iz.EsVacio()) {
                hijo = aux->de.raiz;
            } else {
                hijo = aux->iz.raiz;
            }
            if (padre == NULL) {
                // El nodo a borrar es la raíz
                raiz = hijo;
            } else if (padre->iz.raiz == aux) {
                padre->iz.raiz = hijo;
            } else {
                padre->de.raiz = hijo;
            }
            delete aux;
        } else {
            // Caso 3: Nodo a borrar tiene dos hijos
            nodo_sustituto = aux->de.raiz;
            padre_sustituto = aux;
            while (nodo_sustituto->iz.raiz != NULL) {
                padre_sustituto = nodo_sustituto;
                nodo_sustituto = nodo_sustituto->iz.raiz;
            }
            aux->item = nodo_sustituto->item;
            if (padre_sustituto == aux) {
                padre_sustituto->de.raiz = nodo_sustituto->de.raiz;
            } else {
                padre_sustituto->iz.raiz = nodo_sustituto->de.raiz;
            }
            delete nodo_sustituto;
        }

        // Reequilibrado del árbol
        while (padre != NULL) {
            padre->fe = padre->de.Altura() - padre->iz.Altura();
            if (padre->fe == -2) {
                if (padre->iz.raiz->fe == -1) {
                    // Rotación simple a la derecha
                    RotacionSimpleDerecha(padre);
                } else if (padre->iz.raiz->fe == 1) {
                    // Rotación doble a la derecha
                    RotacionDobleDerecha(padre);
                }
            } else if (padre->fe == 2) {
                if (padre->de.raiz->fe == 1) {
                    // Rotación simple a la izquierda
                    RotacionSimpleIzquierda(padre);
                } else if (padre->de.raiz->fe == -1) {
                    // Rotación doble a la izquierda
                    RotacionDobleIzquierda(padre);
                }
            }
            padre = BuscarPadre(padre->item);
        }
    }
    return retorno;
}

TNodoAVL* TAVLCalendario::BuscarPadre(TCalendario &cal) {
    TNodoAVL *aux = raiz, *padre = NULL;
    while (aux != NULL && aux->item != cal) {
        padre = aux;
        if (cal < aux->item) {
            aux = aux->iz.raiz;
        } else {
            aux = aux->de.raiz;
        }
    }
    return padre;
}

void TAVLCalendario::RotacionSimpleDerecha(TNodoAVL *&nodo) {
    TNodoAVL *aux = nodo->iz.raiz;
    nodo->iz.raiz = aux->de.raiz;
    aux->de.raiz = nodo;
    nodo->fe = nodo->de.Altura() - nodo->iz.Altura();
    aux->fe = aux->de.Altura() - aux->iz.Altura();
    nodo = aux;
}

void TAVLCalendario::RotacionSimpleIzquierda(TNodoAVL *&nodo) {
    TNodoAVL *aux = nodo->de.raiz;
    nodo->de.raiz = aux->iz.raiz;
    aux->iz.raiz = nodo;
    nodo->fe = nodo->de.Altura() - nodo->iz.Altura();
    aux->fe = aux->de.Altura() - aux->iz.Altura();
    nodo = aux;
}

void TAVLCalendario::RotacionDobleDerecha(TNodoAVL *&nodo) {
    RotacionSimpleIzquierda(nodo->iz.raiz);
    RotacionSimpleDerecha(nodo);
}

void TAVLCalendario::RotacionDobleIzquierda(TNodoAVL *&nodo) {
    RotacionSimpleDerecha(nodo->de.raiz);
    RotacionSimpleIzquierda(nodo);
}

TVectorCalendario TAVLCalendario::Inorden() const {
    int pos = 1;
    TVectorCalendario v(Nodos());
    InordenAux(v, pos);
    return v;
}

TVectorCalendario TAVLCalendario::Preorden() const {
    int pos = 1;
    TVectorCalendario v(Nodos());
    PreordenAux(v, pos);
    return v;
}

TVectorCalendario TAVLCalendario::Postorden() const {
    int pos = 1;
    TVectorCalendario v(Nodos());
    PostordenAux(v, pos);
    return v;
}

TVectorCalendario TAVLCalendario::Niveles() const {
    TVectorCalendario v(Nodos());
    if (!EsVacio()) {
        queue<TAVLCalendario> cola;
        int pos = 1;
        cola.push(*this);
        while (!cola.empty()) {
            TAVLCalendario aux = cola.front();
            cola.pop();
            v[pos++] = aux.Raiz();
            if (!aux.raiz->iz.EsVacio()) {
                cola.push(aux.raiz->iz);
            }
            if (!aux.raiz->de.EsVacio()) {
                cola.push(aux.raiz->de);
            }
        }
    }
    return v;
}

TAVLCalendario TAVLCalendario::operator+(const TAVLCalendario &tavl) const {
    TAVLCalendario resultado(*this);
    TVectorCalendario v = tavl.Inorden();
    for (int i = 1; i <= v.Tamano(); i++) {
        resultado.Insertar(v[i]);
    }
    return resultado;
}

TAVLCalendario TAVLCalendario::operator-(const TAVLCalendario &tavl) const {
    TAVLCalendario resultado(*this);
    TVectorCalendario v = tavl.Inorden();
    for (int i = 1; i <= v.Tamano(); i++) {
        resultado.Borrar(v[i]);
    }
    return resultado;
}

ostream& operator<<(ostream &os, const TAVLCalendario &tavl) {
    os << tavl.Inorden();
    return os;
}